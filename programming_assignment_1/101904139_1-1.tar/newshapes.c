/* Dou Jingru
 cs 241L
 This program is modified from myshapes.out to newshapes.c, by changing the 
 character decimal value minus nine in ascii table
*/
#include <stdio.h>
#include <stdlib.h>


/*function to replace ascii symbol to another*/ 

int main(void)
{
/*	example peudo code of the idea replacing character from ascii table
 * char a;
	a = ("%d", c, c);
*/
/* a is _, b is *, d is :, e is +, f is /, g is \, h is -, skip c because it's reserved.*/
	const int SHIFT = -9;
    char a, b, d,e,f,g,h;
    a=95+SHIFT;
    b=42+SHIFT;
    d=58+SHIFT;
    e=43+SHIFT;
    f=47+SHIFT;
    g=92+SHIFT;
    h=45+SHIFT;
	printf("%c%c%c%c%c%c%c%c         %c%c%c%c               %c\n", a,a,a,a,a,a,a,a,b,b,b,b,e);
	printf("%c           %c     %c%c%c%c  %c%c%c%c         %c %c\n",
    d,d,b,b,b,b,b,b,b,b,f,g);
	printf("%c           %c    %c%c%c%c    %c%c%c%c       %c   %c\n",
    d,d,b,b,b,b,b,b,b,b,f,g);
	printf("%c           %c   %c%c%c%c      %c%c%c%c     %c     %c\n",
    d,d,b,b,b,b,b,b,b,b,f,g);
	printf("%c           %c   %c%c%c%c      %c%c%c%c    %c       %c\n",
    d,d,b,b,b,b,b,b,b,b,f,g);
	printf("%c           %c    %c%c%c%c    %c%c%c%c    %c         %c\n",
    d,d,b,b,b,b,b,b,b,b,f,g);
	printf("%c           %c     %c%c%c%c  %c%c%c%c    %c           %c\n",
    d,d,b,b,b,b,b,b,b,b,f,g);
	printf("%c%c%c%c%c%cc%c          %c%c%c%c        %c%c%c%c%c%c%c%c%c\n",
    a,a,a,a,a,a,a,a,b,b,b,b,a,a,a,a,a,a,a,a,a);
	return 0;
}
