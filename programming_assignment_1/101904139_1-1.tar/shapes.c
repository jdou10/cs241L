/*Dou Jingru
  cs241

  This program include how to print out the shapes in shapes.out after modifies helloworld.c program
*/
#include <stdio.h>


int main(void)
{
	printf("Hello world\n");
	printf("______________        ****             +\n");
	printf(":            :     ****  ****         / \\\n");
	printf(":            :    ****    ****       /   \\\n");
	printf(":            :   ****      ****     /     \\\n");
	printf(":            :   ****      ****    /       \\\n");
	printf(":            :    ****    ****    /         \\\n");
	printf(":            :     ****  ****    /           \\\n");
	printf("--------------        ****      /_____________\\\n");
	return 0;
}
